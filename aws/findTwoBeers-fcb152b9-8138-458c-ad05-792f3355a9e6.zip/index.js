
const findTwoBeers = async ( event ) => {
    
    console.log('Loading function');
    
    const { beers, target } = event;
    
    let l = 0;
    let x = 0;
    let s = [];
    let r = [];
  
    l = beers.length - 1;
    s = [...beers].sort();
  
    while (x < l) {
      if (s[x] + s[l] == target) {
        r.push([beers.indexOf(s[x]), beers.indexOf(s[l])]);
        x++;
      } else if (s[x] + s[l] < target) {
        x++;
      } else {
        l--;
      }
    }
    
    const response = {
        statusCode: 200,
        body: JSON.stringify({index : r})
    }
    
    return response;
 };
  
exports.handler = findTwoBeers;
